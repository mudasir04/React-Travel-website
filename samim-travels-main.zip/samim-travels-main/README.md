# Install vite in the react app

<br/>

## Step 1

```
$ npm create vite@latest
```

> after this you select write your `project name ` and after send project name you select which `framework` you want to use and after this you select `javascript`

## Step 2

```
$ npx degit user/project project-name
cd project-name
```

## Step 3

```
$ npm install
```

## Step 4

```
$ npm run dev
```
